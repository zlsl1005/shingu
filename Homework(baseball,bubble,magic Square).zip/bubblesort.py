# -*- coding: utf-8 -*-
def bubbleSort(x):  
	length = len(x)-1
	count = 0
	for i in range(length):
		for j in range(length-i):
			if x[j] > x[j+1]:
				x[j], x[j+1] = x[j+1], x[j]
				count += 1
	print "정렬 횟수(Count) : " + str(count)
	return x


import random
print "정렬시킬 숫자의 개수를 입력하세요(Number)"
j = int(raw_input())
while(j!=0):
        j+=1
        list = [1]*j
        for i in range(j):
              list = random.sample(range(1,j),j-1)

        print "정렬 이전(Not Sort)"
        print list

        bubbleSort(list)
        print "정렬 이후(Sort)"
        print list
        
        print "정렬시킬 숫자의 개수를 입력하세요(Number)"
        j = int(raw_input())

print "프로그램 종료(Exit)"
